﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace App_vol._0_.Data
{
    
    public class Notifications
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)] // Identity attribute
        public int ID{ get; set; }
        public string user_id { get; set; }
        public string? suggestion { get; set; }
        public DateTime? Date { get; set; }


    }
}
