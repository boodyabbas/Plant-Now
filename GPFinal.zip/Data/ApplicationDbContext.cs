﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace App_vol._0_.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        //Getting the notifications table's per user from db
        public DbSet<Notifications> Notifications { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            
        }
    }
}