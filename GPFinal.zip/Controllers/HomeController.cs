﻿using App_vol._0_.Data;
using App_vol._0_.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Security.Claims;

namespace App_vol._0_.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            //var currentUser = As
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId != null)
            {
                List<Notifications> notificationList =
                _context.Notifications.Where(a => a.user_id.Equals(userId)).ToList();
                ViewBag.Notifications = notificationList;
            }
            return View();
        }

        public IActionResult Map()
        {
            return View();
        }

        public IActionResult Weather()
        {
            return View();
        }

        public IActionResult News()
        {
            return View();
        }
        public IActionResult Cam()
        {
            return View();
        }

        public IActionResult plants()
        {
            return View();
        }

        public IActionResult cont()
        {
            return View();
        }
       

        //public IActionResult GetNotifications()
        //{
           
        //    return View();
        //}



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}